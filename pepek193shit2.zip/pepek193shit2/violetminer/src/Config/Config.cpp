// Copyright (c) 2019, Zpalmtree
//
// Please see the included LICENSE file for more information.

//////////////////////////
#include "Config/Config.h"
//////////////////////////

namespace Config
{
    Config config;
};
