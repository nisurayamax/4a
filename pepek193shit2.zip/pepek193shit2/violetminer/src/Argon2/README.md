### argon2-cpp
Implements the argon hash functions with a simple, modern C++ interface.
