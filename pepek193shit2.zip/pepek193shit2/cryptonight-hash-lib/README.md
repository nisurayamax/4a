# cryptonight-hash-lib

Copyright (c) 2017, Sumokoin.org

This a python-wrapper lib to give cryptonight hashing functions for Sumo Easy Miner

To complile on Linux:

	cd /path/to/cryptonight-hash-lib
	cmake .
	make